module.exports=[4825,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28store%29_search_page_actions_14hsvf7.js.map