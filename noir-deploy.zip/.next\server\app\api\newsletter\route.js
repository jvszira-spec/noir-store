var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/newsletter/route.js")
R.c("server/chunks/[root-of-the-server]__1axj8wj._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_0trbmpe._.js")
R.c("server/chunks/_next-internal_server_app_api_newsletter_route_actions_0w29l-i.js")
R.m(81233)
module.exports=R.m(81233).exports
