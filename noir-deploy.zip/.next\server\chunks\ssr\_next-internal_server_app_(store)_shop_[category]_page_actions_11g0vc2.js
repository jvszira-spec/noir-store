module.exports=[63923,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28store%29_shop_%5Bcategory%5D_page_actions_11g0vc2.js.map