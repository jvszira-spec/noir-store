module.exports=[6663,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28store%29_terms_page_actions_1yt6g7i.js.map