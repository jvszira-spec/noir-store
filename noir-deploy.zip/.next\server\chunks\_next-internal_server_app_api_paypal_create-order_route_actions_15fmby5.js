module.exports=[20182,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_paypal_create-order_route_actions_15fmby5.js.map