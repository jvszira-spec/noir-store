var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/products/[id]/images/route.js")
R.c("server/chunks/[root-of-the-server]__05low1f._.js")
R.c("server/chunks/_0trbmpe._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_1qad2xz._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_products_[id]_images_route_actions_1jlr5xu.js")
R.m(14276)
module.exports=R.m(14276).exports
