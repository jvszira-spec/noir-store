var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/categories/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__17wjb73._.js")
R.c("server/chunks/_0trbmpe._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_1qad2xz._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_categories_[id]_route_actions_1wr1q1h.js")
R.m(14046)
module.exports=R.m(14046).exports
