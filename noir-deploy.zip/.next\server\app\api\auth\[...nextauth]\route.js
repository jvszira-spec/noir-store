var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[...nextauth]/route.js")
R.c("server/chunks/[root-of-the-server]__04mvilx._.js")
R.c("server/chunks/_0trbmpe._.js")
R.c("server/chunks/_1qad2xz._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_[___nextauth]_route_actions_08nexdk.js")
R.m(3413)
module.exports=R.m(3413).exports
