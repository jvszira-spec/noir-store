module.exports=[15610,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_%28dashboard%29_inventory_page_actions_1ci0g77.js.map