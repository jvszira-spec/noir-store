var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/checkout/route.js")
R.c("server/chunks/[root-of-the-server]__0g9-tca._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_0trbmpe._.js")
R.c("server/chunks/_next-internal_server_app_api_checkout_route_actions_0jrgp1c.js")
R.m(70797)
module.exports=R.m(70797).exports
