var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/search/route.js")
R.c("server/chunks/[root-of-the-server]__01yb_84._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_0trbmpe._.js")
R.c("server/chunks/_next-internal_server_app_api_search_route_actions_0k0mocb.js")
R.m(62518)
module.exports=R.m(62518).exports
