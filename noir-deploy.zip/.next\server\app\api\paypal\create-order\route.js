var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/paypal/create-order/route.js")
R.c("server/chunks/[root-of-the-server]__1ysnw8y._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_api_paypal_create-order_route_actions_15fmby5.js")
R.m(83373)
module.exports=R.m(83373).exports
