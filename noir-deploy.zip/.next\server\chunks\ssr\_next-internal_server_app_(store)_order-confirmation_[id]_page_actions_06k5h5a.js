module.exports=[6030,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28store%29_order-confirmation_%5Bid%5D_page_actions_06k5h5a.js.map