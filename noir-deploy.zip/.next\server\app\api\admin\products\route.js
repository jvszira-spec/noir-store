var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/products/route.js")
R.c("server/chunks/[root-of-the-server]__1vvt2wi._.js")
R.c("server/chunks/_0trbmpe._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_1qad2xz._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_products_route_actions_1qlniei.js")
R.m(3976)
module.exports=R.m(3976).exports
