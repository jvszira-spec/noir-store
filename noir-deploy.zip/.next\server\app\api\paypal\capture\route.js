var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/paypal/capture/route.js")
R.c("server/chunks/[root-of-the-server]__0j68u6s._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_0trbmpe._.js")
R.c("server/chunks/_next-internal_server_app_api_paypal_capture_route_actions_0xiyfjq.js")
R.m(42582)
module.exports=R.m(42582).exports
