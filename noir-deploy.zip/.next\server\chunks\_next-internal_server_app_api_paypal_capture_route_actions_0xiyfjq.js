module.exports=[73873,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_paypal_capture_route_actions_0xiyfjq.js.map