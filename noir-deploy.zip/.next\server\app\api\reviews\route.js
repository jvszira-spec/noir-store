var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/reviews/route.js")
R.c("server/chunks/[root-of-the-server]__03zyu23._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_0trbmpe._.js")
R.c("server/chunks/_next-internal_server_app_api_reviews_route_actions_0yv3cz6.js")
R.m(83584)
module.exports=R.m(83584).exports
