globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/BYAaLxDudrC4mO1dnDofn/_buildManifest.js",
    "static/BYAaLxDudrC4mO1dnDofn/_ssgManifest.js",
    "static/BYAaLxDudrC4mO1dnDofn/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3yfl9fgvivx3-.js",
    "static/chunks/3-brhv0yt8g3d.js",
    "static/chunks/3kmozkq6tgqnz.js",
    "static/chunks/3jg84jwj6s1uj.js",
    "static/chunks/turbopack-1zr732orgben3.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
